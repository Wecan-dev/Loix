 <?php get_header(); ?>

 <div class="blog-page" style="background-color: #fff!important; ">

  <div class="header "  style="background-image: url(<?php echo get_template_directory_uri(); ?>/assets/images/donacion.png);">
    <div class="mask-blog">
      <h3 style="font-weight: bold; color: #fff; text-align: center; font-size:70px;">TU DONACIÓN</h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit <br> sed do eiusmod
      tempor incididunt ut labore</p>
         <div id="section01" class="demo">
          <a href="#donacion"><span></span></a>
        </div>
    </div>
  </div>
<section id="donacion">
<div class="info-donacion">
  <p style="font-weight: bold;">HA SELECCIONADO</p>
  <h3>EDUCACIÓN A LOS NIÑOS DE LA INDIA </h3>
<div class="text-selec container">
  <p>Menos de la mitad de los niños de la India de entre 6 y 14 años van a la escuela. Como resultado, la India alberga el mayor número de <br> analfabetos del mundo.</p>

  <p style="font-style: italic">Nuestra misión es mejorar la calidad de la educación en la India y garantizar que todos los niños de<br> la India no solo asistan sino que también prosperen en la escuela.<br>
- Pratham Reino Unido</p>

<p>Pratham UK no dejará que India se quede atrás. Al centrarse en las cuatro áreas principales de alfabetización, educación de las niñas, formación profesional e investigación y promoción, la organización ha diseñado un sistema inclusivo de gran alcance que se esfuerza por brindar educación a la mayor cantidad posible de ciudadanos indios.<br><br>

Si desea apoyar esta causa, complete sus datos en el formulario a continuación</p>
</div>  
</div>
<div class="form-complete container">
  <p style="font-weight: bold; font-size: 18px; margin-bottom: 5%;">Completa este formulario</p>
      <div class="form2 ">
          <div class="  flex-this">
          <input type="name" name="" placeholder="Nombre">
          <input type="name" name="" placeholder="Apellido">
            </div>
             <input style="width: 100%;" type="email" name="" placeholder="Correo Electrónico">
        </div>

</div>
<div class="form-complete container">
  <p style="font-weight: bold; font-size: 18px; margin-bottom: 5%;">Comprobante de compra</p>
      <div class="form2 ">
          <div class="  flex-this">
            <div class="first">
              <p><span style="font-weight: bold">Número de serie</span> <br> Ubicado en la parte posterior de su reloj</p>
          <input type="name" name="" placeholder="Bq13345656">
        </div>
            <div class="first">
              <p><span style="font-weight: bold">Número de identificación</span> <br> Impreso en su certificado de su autenticidad</p>
          <input type="name" name="" placeholder="A356778-5567B">
        </div>
            </div>
        </div>
        <div class="btn-done">
        <div class="btn-black">
      <a href="">REALIZA TU DONACIÓN</a>
    </div>
</div>
</div>

</section>

 <?php get_footer(); ?>

