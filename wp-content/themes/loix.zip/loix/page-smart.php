<?php get_header(); ?>


  <div class="header "  style="background-image: url(<?php echo get_template_directory_uri(); ?>/assets/images/banner.png);">
    <div class="mask-blog">
      <h3 style="font-weight: bold; color: #fff; text-align: center; font-size:70px;">SMART</h3>
      <p class="none-this">Lorem ipsum dolor sit amet, consectetur adipisicing elit <br> sed do eiusmod
      tempor incididunt ut labore</p>
         <div id="section01" class="demo">
          <a href="#collections"><span></span></a>
        </div>
         <div class="link-page">
      <a href="#" class="link-page_item">
       <img src="<?php echo get_template_directory_uri(); ?>/assets/images/next.svg"> 
       <p>WOMAN</p>
      </a>
    </div>

       <div class="link-page2">
      <a href="#" class="link-page_item">
       <img src="<?php echo get_template_directory_uri(); ?>/assets/images/left-arrow.svg"> 
       <p>MEN</p>
      </a>
    </div>
    </div>
  </div>

<div id="collections" class="main-banner">
  <div class="main-banner-card">

    <div class="main-banner__item">
      <div class="mask">
        <div class="main-banner__text">
          <div class="main-banner__title">
            <p>GIRO</p>
          </div>
          <div class="main-banner__description">
            <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.
            </p>
          </div>
          <div class="btn_custom" >
           <a href="#gtco-footer">VIEW</a>
         </div>
      </div>
    </div>
    <div class="main-banner__img2">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/images/banner3.png">
    </div>
  
  </div>

</div>
  <div class="main-banner-card">

    <div class="main-banner__item">
      <div class="mask">
        <div class="main-banner__text">
          <div class="main-banner__title">
            <p>NEXUS</p>
          </div>
          <div class="main-banner__description">
            <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.
            </p>
          </div>
          <div class="btn_custom" >
           <a href="#gtco-footer">VIEW</a>
         </div>
      </div>
    </div>
    <div class="main-banner__img2">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/images/banner2.png">
    </div>
  
  </div>

</div>

  <div class="main-banner-card">

    <div class="main-banner__item">
      <div class="mask">
        <div class="main-banner__text">
          <div class="main-banner__title">
            <p>VITAL</p>
          </div>
          <div class="main-banner__description">
            <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.
            </p>
          </div>
          <div class="btn_custom" >
           <a href="#gtco-footer">VIEW</a>
         </div>
      </div>
    </div>
    <div class="main-banner__img2">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/images/banner3.png">
    </div>
  
  </div>

</div>

  <div class="main-banner-card">

    <div class="main-banner__item">
      <div class="mask">
        <div class="main-banner__text">
          <div class="main-banner__title">
            <p>WE CARE</p>
          </div>
          <div class="main-banner__description">
            <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.
            </p>
          </div>
          <div class="btn_custom" >
           <a href="#gtco-footer">VIEW</a>
         </div>
      </div>
    </div>
    <div class="main-banner__img2">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/images/banner3.png">
    </div>
  
  </div>

</div>

</div>

 <?php get_footer(); ?>

