 <?php get_header(); ?>


 <div class="blog-page" style="background-color: #fff!important; ">

  <div class="header "  style="background-image: url(<?php echo get_template_directory_uri(); ?>/assets/images/banner.png);">
    <div class="mask-blog">
      <h3 style="font-weight: bold; color: #fff; text-align: center; font-size:70px;">CATALOGO</h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit <br> sed do eiusmod
      tempor incididunt ut labore</p>
         <div id="section01" class="demo">
          <a href="#about"><span></span></a>
        </div>
    </div>
  </div>
<section id="about" class="container impacto">
  <div class="impacto_child">
    <div class="impacto_child_img">
          <div class="card-cate">
          <div class="img-cate">
            <img style="width: 100%;" src="<?php echo get_template_directory_uri(); ?>/assets/images/catalogo.png">
            <div class="text-cate">
              <h4 style="margin-bottom: 2%;">CATALOGO</h4>
              <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
              <div class="btn_custom">
                  <a href=" ">DESCARGAR</a>
              </div>
            </div>
          </div>
          </div>
    </div>
    <div class="impacto_informacion">
      <p style="font-weight: bold;  margin-bottom: 0;">BIENVENIDOS</p>
      <h3>LOREM IPSUM IS <br> SIMPLY</h3>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
      </p>
    </div>
  </div>
</section>


 <?php get_footer(); ?>

