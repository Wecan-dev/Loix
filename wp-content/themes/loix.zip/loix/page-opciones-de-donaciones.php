 <?php get_header(); ?>



  <div class="header "  style="background-image: url(<?php echo get_template_directory_uri(); ?>/assets/images/banner.png);">
    <div class="mask-blog">
      <h3 style="font-weight: bold; color: #fff; text-align: center; font-size:70px;">OPCIONES DE DONACIÓN</h3>
      <p class="none-this">Lorem ipsum dolor sit amet, consectetur adipisicing elit <br> sed do eiusmod
      tempor incididunt ut labore</p>
         <div id="section01" class="demo">
          <a href="#services"><span></span></a>
        </div>

    </div>
  </div>

<section id="about" class="container impacto">
  <div class="impacto_child">
    <div class="impacto_informacion">
      <p style="color: #000; font-weight: bold; margin-bottom: 0;">GIVE BACK</p>
      <h3>HOW IT WORKS</h3>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
      </p>
          <button class="btn_custom2">
                <a href="#">CLICK HERE TO ADD YOUR CODE</a>
              </button>
    </div>
    <div class="impacto_child_img">
      <img  src="<?php echo get_template_directory_uri(); ?>/assets/images/banner2.png">
    </div>
  </div>

    <div class="impacto_child">
    <div class="impacto_informacion">
      <h3>THE FEELING OF TREES</h3>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
      </p>
          <button class="btn_custom2">
                <a href="#">DONATE NOW</a>
              </button>
    </div>
    <div class="impacto_child_img">
      <img  src="<?php echo get_template_directory_uri(); ?>/assets/images/banner2.png">
    </div>
  </div>

  <div class="impacto_child">
    <div class="impacto_child_img">
      <img  src="<?php echo get_template_directory_uri(); ?>/assets/images/banner2.png">
    </div>
    <div class="impacto_informacion">
      <h3>CHILDREN IN <br> CENTRAL AFRICA</h3>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
      </p>
          <button class="btn_custom2">
                <a href="#">DONATE NOW</a>
              </button>
    </div>
  </div>
      <div class="impacto_child">
    <div class="impacto_informacion">
      <h3>EDUCATION FOR <br> THE CHILDREN OF<br> INDIA</h3>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
      </p>
          <button class="btn_custom2">
                <a href="#">DONATE NOW</a>
              </button>
    </div>
    <div class="impacto_child_img">
      <img  src="<?php echo get_template_directory_uri(); ?>/assets/images/banner2.png">
    </div>
  </div>
</section>

 <?php get_footer(); ?>
