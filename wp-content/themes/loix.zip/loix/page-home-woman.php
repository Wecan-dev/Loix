 <?php get_header(); ?>
<div class="main-banner">
  <div class="main-banner__content">

    <div class="main-banner__item">
      <div class="mask">
        <div class="main-banner__text">
          <div class="main-banner__title">
            <p>ELITE</p>
          </div>
          <div class="main-banner__description">
            <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.
            </p>
          </div>
          <div class="btn_custom" >
           <a href="#gtco-footer">VIEW</a>
         </div>
         <div id="section01" class="demo">
          <a href="#section02"><span></span></a>
        </div>

      </div>
    </div>
    <div class="main-banner__img">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/images/banner.png">

    </div>

    <div class="link-page">
      <a href="#" class="link-page_item">
       <img src="<?php echo get_template_directory_uri(); ?>/assets/images/next.svg"> 
       <p>SMART</p>
      </a>
    </div>

       <div class="link-page2">
      <a href="#" class="link-page_item">
       <img src="<?php echo get_template_directory_uri(); ?>/assets/images/left-arrow.svg"> 
       <p>MEN</p>
      </a>
    </div>
  </div>
  <div class="main-banner__item">
    <div class="mask">
      <div class="main-banner__text">
        <div class="main-banner__title">
          <p>ELITE 2</p>
        </div>
        <div class="main-banner__description">
          <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua.
          </p>
        </div>
        <div class="btn_custom" >
         <a href="#gtco-footer">VIEW</a>
       </div>
       <div id="section01" class="demo">
        <a href="#section02"><span></span></a>
      </div>

    </div>
  </div>
  <div class="main-banner__img">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/banner2.png">
  </div>
      <div class="link-page">
      <a href="#" class="link-page_item">
       <img src="<?php echo get_template_directory_uri(); ?>/assets/images/next.svg"> 
       <p>WOMAN</p>
      </a>
    </div>
</div>
</div>
</div>

<div id="section02" class="main-banner">
  <div class="main-banner__content">

    <div class="main-banner__item">
      <div class="mask">
        <div class="main-banner__text">
          <div class="main-banner__title">
            <p>MEMORIES</p>
          </div>
          <div class="main-banner__description">
            <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.
            </p>
          </div>
          <div class="btn_custom" >
           <a href="#gtco-footer">VIEW</a>
         </div>
         <div id="section01" class="demo">
          <a href="#section03"><span></span></a>
        </div>

      </div>
    </div>
    <div class="main-banner__img">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/images/banner2.png">
    </div>
        <div class="link-page">
      <a href="#" class="link-page_item">
       <img src="<?php echo get_template_directory_uri(); ?>/assets/images/next.svg"> 
       <p>WOMAN</p>
      </a>
    </div>
  </div>
  <div class="main-banner__item">
    <div class="mask">
      <div class="main-banner__text">
        <div class="main-banner__title">
          <p>MEMORIES 2</p>
        </div>
        <div class="main-banner__description">
          <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua.
          </p>
        </div>
        <div class="btn_custom" >
         <a href="#gtco-footer">VIEW</a>
       </div>
       <div id="section01" class="demo">
        <a href="#section03"><span></span></a>
      </div>

    </div>
  </div>
  <div class="main-banner__img">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/banner.png">
  </div>

    <div class="link-page">
      <a href="#" class="link-page_item">
       <img src="<?php echo get_template_directory_uri(); ?>/assets/images/next.svg"> 
       <p>WOMAN</p>
      </a>
    </div>
</div>
</div>
</div>

<div id="section03" class="main-banner">
  <div class="main-banner__content">
    <div class="main-banner__item">
      <div class="mask">
        <div class="main-banner__text">
          <div class="main-banner__title">
            <p>ESSENTIALS</p>
          </div>
          <div class="main-banner__description">
            <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua.
            </p>
          </div>
          <div class="btn_custom" >
           <a href="#gtco-footer">VIEW</a>
         </div>
         <div id="section01" class="demo">
          <a href="#section04"><span></span></a>
        </div>

      </div>
    </div>
    <div class="main-banner__img">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/images/banner3.png">
    </div>
          <div class="link-page">
      <a href="#" class="link-page_item">
       <img src="<?php echo get_template_directory_uri(); ?>/assets/images/next.svg"> 
       <p>WOMAN</p>
      </a>
    </div>
  </div>
  <div class="main-banner__item">
    <div class="mask">
      <div class="main-banner__text">
        <div class="main-banner__title">
          <p>ESSENTIALS 2</p>
        </div>
        <div class="main-banner__description">
          <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua.
          </p>
        </div>
        <div class="btn_custom" >
         <a href="#gtco-footer">VIEW</a>
       </div>
       <div id="section01" class="demo">
        <a href="#section03"><span></span></a>
      </div>

    </div>
  </div>
  <div class="main-banner__img">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/banner2.png">
  </div>
      <div class="link-page">
      <a href="#" class="link-page_item">
       <img src="<?php echo get_template_directory_uri(); ?>/assets/images/next.svg"> 
       <p>WOMAN</p>
      </a>
    </div>
</div>
</div>
</div>


<section id="section04" class="products">
  <h3>PRODUCTS</h3>


  <div class="slider-nav tab2"> 
    <div>
      <button class="tablinks tab-line" onclick="openWork(event, 'NEWARRIVALS')" id="defaultOpen2"><p>NEW ARRIVALS</p></button>
    </div>
    <div>
      <button class="tablinks tab-line" onclick="openWork(event, 'TRENDS')"><p>TRENDS</p></button>
    </div>
    <div>
      <button class="tablinks " onclick="openWork(event, 'BESTSELLERS')"><p>BEST SELLERS</p></button>
    </div>
  </div>



  <div class="slider-for">
    <div id="NEWARRIVALS" class="">
      <div class="multiple-items">
        <div class="block4 card-product">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/image_2.png">
          <div class="text-product">
            <h5>Classic Clock</h5>
            <p>$169,00</p>
            <div class="colors">
              <div class="black"></div>
              <div class="blue"></div>
              <div class="gray"></div>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart trans-0-4">
              <!-- Button -->
              <button class="btn_custom">
                <a href="<?php the_permalink(); ?>">VER MÁS</a>
              </button>
            </div>
          </div>
        </div>

        <div class="block4 card-product">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/image_3.png">
          <div class="text-product">
            <h5>Classic Clock</h5>
            <p>$169,00</p>
            <div class="colors">
              <div class="black"></div>
              <div class="blue"></div>
              <div class="gray"></div>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart trans-0-4">
              <!-- Button -->
              <button class="btn_custom">
                <a href="<?php the_permalink(); ?>">VER MÁS</a>
              </button>
            </div>
          </div>
        </div>
        <div class="block4 card-product">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/image_4.png">
          <div class="text-product">
            <h5>Classic Clock</h5>
            <p>$169,00</p>
            <div class="colors">
              <div class="black"></div>
              <div class="blue"></div>
              <div class="gray"></div>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart trans-0-4">
              <!-- Button -->
              <button class="btn_custom">
                <a href="<?php the_permalink(); ?>">VER MÁS</a>
              </button>
            </div>
          </div>
        </div>
        <div class="block4 card-product">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/image_2.png">
          <div class="text-product">
            <h5>Classic Clock</h5>
            <p>$169,00</p>
            <div class="colors">
              <div class="black"></div>
              <div class="blue"></div>
              <div class="gray"></div>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart trans-0-4">
              <!-- Button -->
              <button class="btn_custom">
                <a href="<?php the_permalink(); ?>">VER MÁS</a>
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>

    <div id="TRENDS" class="">
      <div class="multiple-items">
        <div class="block4 card-product">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/image_3.png">
          <div class="text-product">
            <h5>Classic Clock</h5>
            <p>$169,00</p>
            <div class="colors">
              <div class="black"></div>
              <div class="blue"></div>
              <div class="gray"></div>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart trans-0-4">
              <button class="btn_custom">
                <a href="<?php the_permalink(); ?>">VER MÁS</a>
              </button>
            </div>
          </div>
        </div>
        <div class="block4 card-product">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/image_2.png">
          <div class="text-product">
            <h5>Classic Clock</h5>
            <p>$169,00</p>
            <div class="colors">
              <div class="black"></div>
              <div class="blue"></div>
              <div class="gray"></div>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart trans-0-4">
              <button class="btn_custom">
                <a href="<?php the_permalink(); ?>">VER MÁS</a>
              </button>
            </div>
          </div>
        </div>

        <div class="block4 card-product">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/image_2.png">
          <div class="text-product">
            <h5>Classic Clock</h5>
            <p>$169,00</p>
            <div class="colors">
              <div class="black"></div>
              <div class="blue"></div>
              <div class="gray"></div>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>
            <div class="block2-btn-addcart trans-0-4">
              <button class="btn_custom">
                <a href="<?php the_permalink(); ?>">VER MÁS</a>
              </button>
            </div>
          </div>
        </div>
        <div class="block4 card-product">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/image_4.png">
          <div class="text-product">
            <h5>Classic Clock</h5>
            <p>$169,00</p>
            <div class="colors">
              <div class="black"></div>
              <div class="blue"></div>
              <div class="gray"></div>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart trans-0-4">
              <button class="btn_custom">
                <a href="<?php the_permalink(); ?>">VER MÁS</a>
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>

    <div id="BESTSELLERS" class="">

      <div class="multiple-items">
        <div class="block4 card-product">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/image_2.png">
          <div class="text-product">
            <h5>Classic Clock</h5>
            <p>$169,00</p>
            <div class="colors">
              <div class="black"></div>
              <div class="blue"></div>
              <div class="gray"></div>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart trans-0-4">
              <button class="btn_custom">
                <a href="<?php the_permalink(); ?>">VER MÁS</a>
              </button>
            </div>
          </div>
        </div>

        <div class="block4 card-product">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/image_3.png">
          <div class="text-product">
            <h5>Classic Clock</h5>
            <p>$169,00</p>
            <div class="colors">
              <div class="black"></div>
              <div class="blue"></div>
              <div class="gray"></div>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart trans-0-4">
              <button class="btn_custom">
                <a href="<?php the_permalink(); ?>">VER MÁS</a>
              </button>
            </div>
          </div>
        </div>
        <div class="block4 card-product">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/image_4.png">
          <div class="text-product">
            <h5>Classic Clock</h5>
            <p>$169,00</p>
            <div class="colors">
              <div class="black"></div>
              <div class="blue"></div>
              <div class="gray"></div>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart trans-0-4">
              <!-- Button -->
              <button class="btn_custom">
                <a href="<?php the_permalink(); ?>">VER MÁS</a>
              </button>
            </div>
          </div>
        </div>
        <div class="block4 card-product">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/image_2.png">
          <div class="text-product">
            <h5>Classic Clock</h5>
            <p>$169,00</p>
            <div class="colors">
              <div class="black"></div>
              <div class="blue"></div>
              <div class="gray"></div>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart trans-0-4">
              <button class="btn_custom">
                <a href="<?php the_permalink(); ?>">VER MÁS</a>
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <div id="section07" class="demo">
    <a href="#section05"><span></span></a>
  </div>
</section>


<section id="section05" class="text-cta">
  <div class="text-cta_flex">
    <div class="text-cta_item">
      <img src="<?php echo get_template_directory_uri(); ?>/assets/images/image.png">
      <div class="text-overlay">
        <h3>GIVING BACK <br> PROGRAM</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua.</p>
        <div class="btn_custom" >
         <a href="#gtco-footer">DISCOVER MORE</a>
       </div>
     </div>
   </div>

   <div class="text-cta_item">
    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/group.png">
    <div class="text-overlay">
      <h3>BE PART OF <br>THE COMMUNITY</h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
      tempor incididunt ut labore et dolore magna aliqua.</p>
      <div class="btn_custom" >
       <a href="#gtco-footer">SEE MORE</a>
     </div>
   </div>
 </div>
</div>
</section>

 <?php get_footer(); ?>

