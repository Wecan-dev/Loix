 <?php get_header(); ?>

 <div class="blog-page" style="background-color: #fff!important; ">

  <div class="header "  style="background-image: url(<?php echo get_template_directory_uri(); ?>/assets/images/banner.png);">
    <div class="mask-blog">
      <h3 style="font-weight: bold; color: #fff; text-align: center; font-size:70px;">GIVE BACK</h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit <br> sed do eiusmod
      tempor incididunt ut labore</p>
         <div id="section01" class="demo">
          <a href="#about"><span></span></a>
        </div>
    </div>
  </div>
<section id="about" class="container impacto">
  <div class="impacto_child">
    <div class="impacto_informacion">
      <h3>GIVING BACK <br> PROGRAM</h3>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
      </p>
    </div>
    <div class="impacto_child_img2">
      <img  src="<?php echo get_template_directory_uri(); ?>/assets/images/banner2.png">
    </div>
  </div>
</section>

<section class="great">
  <p>GIVE BACK</p>
<h3>OUR THREE GREAT CAUSES</h3>
  <div style="justify-content: space-around;" class="valores_child">
    <div class="icon-valores icon-act">
      <div class="text-act2">
        <div style="margin-left: 5%;" class="categ">
          <p>ENVIROMENT</p>
          <h5>THE FEELING OF TREES</h5>
        </div>
        <div style="margin-left: 5%;" class="title-actv">
          <h6>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua.</h6>
        </div>
      </div>
    </div>
    <div class="icon-valores icon-act">
      <div class="text-act2">
        <div style="margin-left: 5%;" class="categ">
          <p>HEALTH</p>
          <h5>CHILDREN IN <br> CENTRAL AFRICA</h5>
        </div>
        <div style="margin-left: 5%;" class="title-actv">
          <h6>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua.</h6>
        </div>
      </div>
    </div>
    <div class="icon-valores icon-act">
      <div class="text-act2">
        <div style="margin-left: 5%;" class="categ">
          <p>EDUCATION</p>
          <h5>EDUCATION FOR THE <br> CHILDREN OF INDIA</h5>
        </div>
        <div style="margin-left: 5%;" class="title-actv">
          <h6>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua.</h6>
        </div>
      </div>
    </div>

  </div>

</section>

<section id="about" class="container impacto">
  <div class="impacto_child">
    <div class="impacto_informacion">
      <p style="color: #000; font-weight: bold; margin-bottom: 0;">GIVE BACK</p>
      <h3>HOW IT WORKS</h3>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
      </p>
          <button class="btn_custom2">
                <a href="#">CLICK HERE TO ADD YOUR CODE</a>
              </button>
    </div>
    <div class="impacto_child_img">
      <img  src="<?php echo get_template_directory_uri(); ?>/assets/images/banner2.png">
    </div>
  </div>
</section>


 <?php get_footer(); ?>
