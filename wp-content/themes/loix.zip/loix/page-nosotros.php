 <?php get_header(); ?>
 <div class="blog-page" style="background-color: #fff!important; ">

  <div class="header "  style="background-image: url(<?php echo get_template_directory_uri(); ?>/assets/images/banner.png);">
    <div class="mask-blog">
      <h3 style="font-weight: bold; color: #fff; text-align: center; font-size:70px;">NOSOTROS</h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit <br> sed do eiusmod
      tempor incididunt ut labore</p>
         <div id="section01" class="demo">
          <a href="#about"><span></span></a>
        </div>
    </div>
  </div>
<section id="about" class="container impacto">
  <div class="impacto_child">
    <div class="impacto_informacion">
      <h3>HISTORIA</h3>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
      </p>
    </div>
    <div class="impacto_child_img2">
      <img  src="<?php echo get_template_directory_uri(); ?>/assets/images/nosotros.png">
    </div>
  </div>
</section>

<section>
<div class="valores">
<h3>INICIATIVAS</h3>
  <div class="valores_child">
    <div class="icon-valores icon-act wow fadeInUp" data-wow-duration="2s">
      <div class="act-img">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/team.svg">
      </div>
      <div class="text-act">
     
        <div style="margin-left: 5%;" class="categ">
          <p>Lorem ipsum </p>
        </div>
        <div style="margin-left: 5%;" class="title-act">
          <h6>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua.</h6>
        </div>
      </div>
    </div>
      <div class="icon-valores icon-act wow fadeInUp" data-wow-duration="2s">
      <div class="act-img">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/cardboard.svg">
      </div>
      <div class="text-act">
     
        <div style="margin-left: 5%;" class="categ">
          <p>Lorem ipsum </p>
        </div>
        <div style="margin-left: 5%;" class="title-act">
          <h6>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua.</h6>
        </div>
      </div>
    </div>
      <div class="icon-valores icon-act wow fadeInUp" data-wow-duration="2s">
      <div class="act-img">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/deposit.svg">
      </div>
      <div class="text-act">
     
        <div style="margin-left: 5%;" class="categ">
          <p>Lorem ipsum </p>
        </div>
        <div style="margin-left: 5%;" class="title-act">
          <h6>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua.</h6>
        </div>
      </div>
    </div>
      <div class="icon-valores icon-act wow fadeInUp" data-wow-duration="2s">
      <div class="act-img">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/cardboard2.svg">
      </div>
      <div class="text-act">
     
        <div style="margin-left: 5%;" class="categ">
          <p>Lorem ipsum </p>
        </div>
        <div style="margin-left: 5%;" class="title-act">
          <h6>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua.</h6>
        </div>
      </div>
    </div>
  </div>
</div>
</section>

<section id="about" class="container impacto">
  <div class="impacto_child">
    <div class="impacto_informacion">
      <h3>MISIÓN</h3>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.    </p>
        <div style="display: flex; align-items: baseline;">
        <span class="fa fa-check"></span> <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p><br>    </div>
       <div style="display: flex; align-items: baseline;">
        <span class="fa fa-check"></span> <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p><br>    </div>  
         <div style="display: flex; align-items: baseline;">
        <span class="fa fa-check"></span> <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p><br>   
         </div>
         <div style="display: flex; align-items: baseline;">
        <span class="fa fa-check"></span> <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p><br>   
         </div>  
          <div style="display: flex; align-items: baseline;">
        <span class="fa fa-check"></span> <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p><br>  
          </div>
  

  </div>
    <div class="impacto_child_img">
      <img  src="<?php echo get_template_directory_uri(); ?>/assets/images/about2.png">
    </div>
</section>

<section class="vistas">
  <h3>ULTIMAS VISTAS</h3>
      <div class="multiple-items">
        <div class="block4 card-product">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/card1.png">
          <div class="text-product">
            <h5>Classic Clock</h5>
            <p>$169,00</p>
            <div class="colors">
              <div class="black"></div>
              <div class="blue"></div>
              <div class="gray"></div>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart trans-0-4">
              <!-- Button -->
              <button class="btn_custom">
                <a href="<?php the_permalink(); ?>">VER MÁS</a>
              </button>
            </div>
          </div>
        </div>

        <div class="block4 card-product">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/card2.png">
          <div class="text-product">
            <h5>Classic Clock</h5>
            <p>$169,00</p>
            <div class="colors">
              <div class="black"></div>
              <div class="blue"></div>
              <div class="gray"></div>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart trans-0-4">
              <!-- Button -->
              <button class="btn_custom">
                <a href="<?php the_permalink(); ?>">VER MÁS</a>
              </button>
            </div>
          </div>
        </div>
        <div class="block4 card-product">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/card1.png">
          <div class="text-product">
            <h5>Classic Clock</h5>
            <p>$169,00</p>
            <div class="colors">
              <div class="black"></div>
              <div class="blue"></div>
              <div class="gray"></div>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart trans-0-4">
              <!-- Button -->
              <button class="btn_custom">
                <a href="<?php the_permalink(); ?>">VER MÁS</a>
              </button>
            </div>
          </div>
        </div>
        <div class="block4 card-product">
          <img src="<?php echo get_template_directory_uri(); ?>/assets/images/card2.png">
          <div class="text-product">
            <h5>Classic Clock</h5>
            <p>$169,00</p>
            <div class="colors">
              <div class="black"></div>
              <div class="blue"></div>
              <div class="gray"></div>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart trans-0-4">
              <!-- Button -->
              <button class="btn_custom">
                <a href="<?php the_permalink(); ?>">VER MÁS</a>
              </button>
            </div>
          </div>
        </div>

      </div>
</section>
 <?php get_footer(); ?>
